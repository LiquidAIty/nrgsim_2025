// Bittrex API V3 plugin for Zorro ////////////////////////////
// Doc: https://bittrex.github.io/api/v3
// Link with ZorroDLL.cpp

#include "stdafx.h" // includes windows.h
#include <string>
#include <math.h>
#include <ATLComTime.h>
#include <zorro.h>

#define PLUGIN_TYPE	2
#define PLUGIN_NAME	"Bittrex V3"
#define PLUGIN_VERSION "3.02"
#define DLLFUNC extern "C" __declspec(dllexport)
#define RHEADER "https://api.bittrex.com/v3/"

// Global vars ///////////////////////////////////////////////////////////

int (__cdecl *BrokerMessage)(const char *Text) = NULL;
int (__cdecl *BrokerProgress)(intptr_t Progress) = NULL;

struct GLOBAL {
	int Diag;
	int HttpId;
	int PriceType,VolType,OrderType;
	double Unit;
	char Url[256]; // send URL buffer
	char Key[256],Secret[256]; // credentials
	char Symbol[64],Uuid[256]; // last trade, symbol and Uuid
	char AccountId[16]; // account currency
} G; // parameter singleton

// Utility functions /////////////////////////////////////////////////////////

// display message on the Zorro log
void showMsg(const char* Text,const char *Detail)
{
	static char Msg[4096];
	sprintf_s(Msg,"%s %s",Text,Detail);
	BrokerMessage(Msg);
}

// 64 bit integer to text
char* i64toa(__int64 n)
{
	static char buffer[64];
	if(0 != _i64toa_s(n,buffer,64,10)) *buffer = 0;
	return buffer;
}

// float to text, resolution dependent
char* ftoa(double f)
{
	static char buffer[64];
	if(f < 1.)
		sprintf(buffer,"%.8f",f);
	else if(f < 30.)
		sprintf(buffer,"%.4f",f);
	else if(f < 300) 
		sprintf(buffer,"%.2f",f); // avoid "invalid precision"
	else 
		sprintf(buffer,"%.0f",f);
	return buffer;
}

// keep Zorro responsive
int sleep(int ms)
{
	Sleep(ms); 
	return BrokerProgress(0);
}

// logged in?
inline BOOL isConnected()
{
	return *G.Key != 0;
}

// convert ETH/BTC -> ETH-BTC
char* fixSymbol(const char* Symbol)
{
	static char NewSymbol[32];
	strcpy_s(NewSymbol,Symbol);
	char* Slash = strchr(NewSymbol,'/');
	if(Slash) *Slash = '-';
	return NewSymbol;
}

// convert to power of 10
double fixAmount(double Val)
{
	int Exp = log10(Val);
	if (Exp >= 0) Exp++;
	return pow(10,Exp);
}

// send request to API
// Mode & 2: Use second reponse buffer
// Mode & 1: use authentication
char* send(const char* Path,int Mode = 0,const char* Method = NULL,const char* Body = NULL)
{
	static char URL[1024], Header[2048], Signature[1024],
		Buffer1[1024*1024], Buffer2[2048];
	*Signature = *Header = 0;
	sprintf_s(URL,"%s%s",RHEADER,Path);
	char* Response = Mode & 2? Buffer2 : Buffer1;
	int MaxSize = Mode & 2? sizeof(Buffer2) : sizeof(Buffer1);
	if (Mode & 1) { // Authentication required
		strcpy_s(Header, "Content-Type:application/json");
		strcat_s(Header, "\nAccept:application/json");
		strcat_s(Header, "\nApi-Key: ");
		strcat_s(Header,G.Key);
		strcat_s(Header, "\nApi-Timestamp: ");
		__time64_t Time; _time64(&Time);
		static __time64_t Offset = 0;
		char* TimeStamp = i64toa(Time*1000 + Offset++); 
		strcat_s(Header, TimeStamp);
		strcat_s(Header, "\nApi-Content-Hash: ");
		char* Hash = hmac(Body, 0, 0, 512);
		strcat_s(Header,Hash);
		strcpy_s(Signature, TimeStamp);
		strcat_s(Signature, URL);
		if(Method && *Method)
			strcat_s(Signature, Method);
		else if(!Body)
			strcat_s(Signature,"GET");
		else
			strcat_s(Signature,"POST");
		strcat_s(Signature, Hash);
		strcat_s(Header, "\nApi-Signature: ");
		strcat_s(Header, hmac(Signature, 0, G.Secret,512));
	}
	if((Mode & 1) && G.Diag >= 2)
		showMsg("Send:",Path);
	int Id = http_request(URL,Body,Header,Method);
	if(!Id) goto send_error;
// wait 30 seconds for the server to reply
	int Size = 0, Wait = 3000;  
	while (!(Size = http_status(Id)) && --Wait > 0)
		if(!sleep(10)) goto send_error;

	if (!Size) goto send_error;
	if(!http_result(Id,Response,MaxSize))
		goto send_error;
	Response[MaxSize-1] = 0; // prevent buffer overrun
	if(Mode & 1 && G.Diag >= 2)
		showMsg("Resp:", Response);
	if(Mode & 1) http_free(Id);
	else G.HttpId = Id; // keep stream open
	return Response;

// transfer unsuccessful?
send_error:
	if(Id) http_free(Id);
	G.HttpId = 0;
	if(G.Diag >= 1)
		showMsg("Failed:",Path);
	return NULL;
}

////////////////////////////////////////////////////////////////

DLLFUNC int BrokerOpen(char* Name,FARPROC fpMessage,FARPROC fpProgress)
{
	strcpy_s(Name,32,PLUGIN_NAME);
	(FARPROC&)BrokerMessage = fpMessage;
	(FARPROC&)BrokerProgress = fpProgress;
	return PLUGIN_TYPE;
}

DLLFUNC char* BrokerRequest(const char* Path,const char* Method,const char* Data)
{
	int Mode = 0;
	if (Method && *Method == '$') { // use authorization
		if (!isConnected()) return NULL;
		Method++;
		Mode = 1;
	}
	return send(Path,Mode,Method,Data);
}

DLLFUNC int BrokerAsset(char* Symbol,double* pPrice,double* pSpread,
	double *pVolume, double *pPip, double *pPipCost, double *pMinAmount,
	double *pMargin, double *pRollLong, double *pRollShort)
{
	sprintf_s(G.Url,"markets/%s/ticker",fixSymbol(Symbol));
	char* Response = send(G.Url,2);
	if(!Response) return 0;
	double Bid = strvar(Response, "bidRate", 0.),
		Ask = strvar(Response,"askRate",0.);
	if (Ask > 0. && Bid > 0. && pSpread) 
		*pSpread = Ask - Bid;
	double Last = strvar(Response, "lastTradeRate", 0.);
	if(Ask == 0. || G.PriceType == 2) 
		Ask = Last;
	if (Ask == 0.) return 0; // symbol does not exist
	if(pPrice) *pPrice = Ask;
	if(pVolume) {
		sprintf_s(G.Url,"markets/%s/summary",fixSymbol(Symbol));
		Response = send(G.Url,2);
		if (Response) {
			if (G.VolType == 4)
				*pVolume = strvar(Response, "volume", 0);
			else
				*pVolume = strvar(Response, "quoteVolume", 0);
		}
	}
	if (pMinAmount) {
		sprintf_s(G.Url,"markets/%s",fixSymbol(Symbol));
		Response = send(G.Url,2);
		if (Response) {
			*pMinAmount = fixAmount(strvar(Response,"minTradeSize",0.000001));
			if (pPip) {
				int Exp = strvar(Response,"precision",8);
				*pPip = pow(10,-Exp); 
				//*pPip = fixAmount(Ask*0.0001);
				while (*pPip * *pMinAmount < 0.000000001)
					*pPip *= 10; // avoid too small pip cost
				if (pPipCost)
					*pPipCost = *pPip * *pMinAmount;
			}
		}
	}
	if (pMargin) 
		*pMargin = -100; // no leverage
	return 1;
}	

DLLFUNC int BrokerHistory2(char* Symbol,DATE Start,DATE End,int TickMinutes,int NTicks,T6* Ticks)
{
	if (!Ticks || !NTicks) return 0;
// calculate interval and tick duration
	char* Interval = "MINUTE_1";
	DATE TickSpan = 1. / 1440; // 1 minute
	if (1440 <= TickMinutes) Interval = "DAY_1", TickSpan = 1.;
	else if (60 <= TickMinutes) Interval = "HOUR_1", TickSpan = 1./24;

// history ends on current day? Then use a different command 
	SYSTEMTIME Time,Today;
	VariantTimeToSystemTime(End,&Time);
	GetSystemTime(&Today);
	bool EndsToday = (Time.wYear == Today.wYear && Time.wMonth == Today.wMonth && Time.wDay == Today.wDay);
	if(EndsToday)
		sprintf_s(G.Url, "markets/%s/candles/%s/recent",fixSymbol(Symbol),Interval);
	else {
// get batch start time
		VariantTimeToSystemTime(End - NTicks*TickSpan,&Time);
		sprintf_s(G.Url, "markets/%s/candles/%s/historical/%4d/%02d/%02d",
			fixSymbol(Symbol),Interval,Time.wYear,Time.wMonth,Time.wDay);
	}
	char* Response = send(G.Url);
	if (!Response) return 0;
// store the ticks
	int TicksReceived = 0;
	while(TicksReceived < NTicks) {
		char* Position = strrchr(Response, '{'); // find last candle
		if (!Position) break;
		char* StartsAt = strtext(Position, "startsAt", "");
		if (!*StartsAt) break;
		sscanf_s(StartsAt, "%4hd-%2hd-%2hdT%2hd:%2hd:%2hd",// "2021-12-28T20:47:13.85Z"
			&Time.wYear, &Time.wMonth, &Time.wDay, &Time.wHour, &Time.wMinute, &Time.wSecond);
		SystemTimeToVariantTime(&Time, &Ticks->time);
		Ticks->time += TickSpan; // adjust timestamp to end of tick
		if (Ticks->time < Start) break;
		if (Ticks->time > End) {
			*Position = 0; // go back one candle
			continue;
		}
		Ticks->fOpen = strvar(Position, "open", 0);
		Ticks->fHigh = strvar(Position, "high", 0);
		Ticks->fLow = strvar(Position, "low", 0);
		Ticks->fClose = strvar(Position, "close", 0);
		Ticks->fVol = strvar(Position, "volume", 0);
		Ticks++;
		TicksReceived++;
		*Position = 0; // go back one candle
	}
	return TicksReceived;
}

DLLFUNC int BrokerAccount(char* AccountId,double *pdBalance,double *pdTradeVal,double *pdMarginVal)
{
	if(!isConnected()) return 0;
	if (AccountId && *AccountId)
		strcpy_s(G.AccountId,AccountId);
	else if(!*G.AccountId)
		strcpy_s(G.AccountId,"BTC");
	strcpy_s(G.Url,"balances");
	if (!pdTradeVal) {
		strcat_s(G.Url,"/");
		strcat_s(G.Url,AccountId);
	}
	char* Response = send(G.Url,1);
	if(!Response) return 0;
	double OpenVal = 0.;
	while (Response) {
		char* Symbol = strtext(Response,"currencySymbol","");
		double Position = strvar(Response,"total",0.);
		Response = strchr(++Response,'{');
		if (Position == 0.) continue;
// Account position? Store balance
		if (0 == strcmpi(Symbol,G.AccountId)) {
			if (pdBalance) *pdBalance = Position;
			if (!pdTradeVal) return 1;
		}
		else if(*Symbol) { // get rate and add to TradeVal
			char Market[16];
			sprintf(Market,"%s/%s",Symbol,G.AccountId);
			double Rate = 0;
			if (BrokerAsset(Market,&Rate,0,0,0,0,0,0,0,0))
				if (Rate > 0.)
					OpenVal = Position*Rate;
		}
	}
	if (pdTradeVal) *pdTradeVal = OpenVal;
	return 1;
}


// returns negative amount when the trade was closed
DLLFUNC int BrokerTrade(int nTradeID,double *pOpen,double *pClose,double *pRoll,double *pProfit)
{
	if(!isConnected() || !*G.Uuid) return 0;

	sprintf_s(G.Url,"orders/%s",G.Uuid);
	char* Response = send(G.Url,1);
	if(!Response) return NAY;
	double Filled = strvar(Response,"fillQuantity",0);
	double Price = strvar(Response,"proceeds",0);
	if (Filled && Price > 0 && pOpen)
		*pOpen = Price/Filled;
	char* Status = strtext(Response,"status","");
	if(0 == strcmpi(Status,"OPEN") || 0 == strcmpi(Status,"CLOSED"))
		return Filled/min(1.,G.Unit);
	else return NAY; // order not found
}

DLLFUNC int BrokerBuy2(char* Symbol,int Volume,double StopDist,double Limit,double *pPrice,int *pFill)
{
	if(!isConnected() || !Volume) return 0;

// compose the body
	char Body[256] = "{\n";
	strcat_s(Body,"\"marketsymbol\": \"");
	strcat_s(Body,fixSymbol(Symbol));
	strcat_s(Body,"\",\n\"direction\": \"");
	strcat_s(Body,Volume > 0? "BUY" : "SELL");
	strcat_s(Body,"\",\n\"type\": \"");
	strcat_s(Body,Limit > 0. ? "LIMIT" : "MARKET");
	strcat_s(Body,"\",\n\"quantity\": \"");
	double Size = labs(Volume);
	if(G.Unit < 1.) Size *= G.Unit;
	strcat_s(Body,ftoa(Size));
// TEST: Contracts when G.Unit > 1
	if (Limit > 0.) {
		strcat_s(Body,"\",\n\"limit\": \"");
		strcat_s(Body,ftoa(Limit));
	}
	strcat_s(Body,"\",\n\"timeInForce\": \"");
	if ((G.OrderType&2) && Limit > 0.) 
		strcat_s(Body,"GOOD_TIL_CANCELLED"); // limit orders only
	else if (G.OrderType&1) 
		strcat_s(Body,"FILL_OR_KILL"); // fill all or nothing
	else 
		strcat_s(Body,"IMMEDIATE_OR_CANCEL");
	strcat_s(Body,"\"\n}");

	char* Response = send("orders",1,0,Body);
	if(!Response) return 0;
	char* Uuid = strtext(Response,"id","");
	if(!*Uuid) {
		showMsg("Failed:",Response);
		return 0;
	}
	strcpy(G.Uuid,Uuid);
	double Filled = strvar(Response,"fillQuantity",0);
	if(Filled == 0. && !(G.OrderType&2)) {
		showMsg("FOK/IOC order","unfilled");
		return 0;
	}
	double Price = strvar(Response,"proceeds",0);
	if (Filled > 0. && Price > 0. && pPrice)
		*pPrice = Price/Filled;
	if (*pFill) *pFill = Filled/min(1.,G.Unit);
	return -1; // get id with GET_UUID
}

DLLFUNC int BrokerLogin(char* User,char* Pwd,char* Type,char* Accounts)
{
	if(User) { // login
		memset(&G,0,sizeof(G));
		G.Unit = 0.00001;
		strcpy_s(G.Key,User);
		strcpy_s(G.Secret,Pwd);
		if(!*User || !*Pwd)
			showMsg("Prices only","");
		else if(!BrokerAccount(Accounts,NULL,NULL,NULL))
			return 0; // invalid credentials
		else 
			showMsg("Bittrex plugin",PLUGIN_VERSION); // all ok
		return 1;
	} else { // logout
		if(G.HttpId) 
			http_free(G.HttpId);
	}
	return 0;
}

//////////////////////////////////////////////////////////////
DLLFUNC double BrokerCommand(int Mode,intptr_t Parameter)
{
	switch(Mode) {
		case GET_COMPLIANCE: return 2;
		case GET_MAXREQUESTS: return 2;
		case SET_DIAGNOSTICS: 
			G.Diag = Parameter; return 1;
		case SET_AMOUNT: 
			G.Unit = *(double*)Parameter; 
			if (G.Unit <= 0.) G.Unit = 0.00001;
			return 1;
		
		case GET_UUID: 
			strcpy_s((char*)Parameter,256,G.Uuid); return 1;
		case SET_UUID: 
			strcpy_s(G.Uuid,(char*)Parameter); return 1;
		case SET_VOLTYPE: 
			G.VolType = Parameter; return 1;
		case SET_PRICETYPE: 
			G.PriceType = Parameter; return 1;
		case SET_ORDERTYPE: 
			G.OrderType = Parameter; return Parameter&3;

		case GET_POSITION: {
			double Value = 0;
			char* Coin = fixSymbol((char*)Parameter);
			char* End = strchr(Coin,'-');
			if (End) {
				*End = 0;
				BrokerAccount(Coin,&Value,NULL,NULL);
			}
			return Value/min(1.,G.Unit);
		}

		case DO_CANCEL: {
			char* Response;
			if (Parameter == 0) {
				Response = send("orders/open",1,"DELETE");
				if (Response) return 1;
			} 
			else {
				sprintf_s(G.Url,"orders/%s",G.Uuid);
				Response = send(G.Url,1,"DELETE");
				if (Response) return 1;
				//var Quantity = strvar(Response,"fillQuantity",0);
				//return Quantity;
			} 
			return 0;
		}

	}
	return 0.;
}

